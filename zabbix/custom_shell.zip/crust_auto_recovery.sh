#!/bin/bash
interval_time=60          # 再次检测的时间间隔
work_dir='/etc/zabbix/'
max_used_space=98        # 磁盘空间的最大使用率
logs_line=10             # 搜索日志的行数（表示最后10行）
recovery_log_name='recovery.log'      # 定义脚本日志文件名称
docker_log_size=50M      # 清理大于50M的docker日志
log_save_rows=1000       # 清理日志文件时，默认留下多少行

# 铲库重置
full_del_data(){

  del_path="/opt/crust/data/$server/"
  exclude_dev=$(sudo df -Th | awk -F '[ %]' '{if ($NF=="/") print $1}')
  crust stop;for i in $(ls /dev/[sh]d[a-z\|0-9]* | grep -v $exclude_dev);do umount $i; mkfs.xfs $i;done;mount -a;rm -rf $del_path;crust reload; sudo crust tools upgrade-image $server && sudo crust reload $server
}

# 修改crust 工作量
change_srd(){

  available_srd=$(cd $work_dir || exit;crust tools workload > available_srd.txt; cat available_srd.txt | grep disk_available_for_srd | awk -F '[ ,]' '{print $(NF-1)}'; rm -rf available_srd.txt)
  if [[ $available_srd != 0 ]];then crust tools change-srd $available_srd;fi
}

# 获取容器名称用于日志查看
get_docker_name(){
  docker_name=$(docker ps -a | grep $server | awk '{print $NF}')
  # 如果是 chain 服务，则替换名称为 crust（服务器当中的容器名称为crust）
  if [[ $server == 'chain' ]];then docker_name='crust';fi
}

# 判断服务状态是否正常
status_is_ok(){
  get_docker_name
  status=$(sudo /usr/bin/crust status  |grep $server |awk '{print $2}')
  [[ $status == 'running' && ! $(docker logs $docker_name --tail $logs_line 2> /dev/null | grep 'ERROR') ]]
}

# 检查磁盘状态
disk_space_isok(){
  current_space=$(sudo df -Th | awk -F '[ %]' '{if ($NF=="'"$fs"'") print $(NF-2)}')
  [[ $current_space < $max_used_space ]]
}

# 日志写入
log_in(){
  cd $work_dir || exit;echo "$(date  '+%Y-%m-%d %H:%M') $1 recover $2" >> $recovery_log_name
}

# 执行操作后对服务状态进行验证
end_status_check_and_inlog(){
  if status_is_ok;then
    log_in "$server" 'success'
    exit 0
  elif ! status_is_ok;then
    log_in "$server" 'faild'
    exit 1
  fi
}

# 重启服务
reload_server(){

  crust reload $1
  sleep $interval_time
}

# 清理分区，需传入变量fs
clean_fs(){
  if [[ $1 ]];then
    # $1为传入的其他步骤
    $1
  else
    # 默认操作
    cd $fs || exit;for i in $(find . -size +"$docker_log_size" | grep -E "log$|out$");do tail -n $log_save_rows $i > $i;done
  fi
}

recovery_sworker(){
  server='sworker'

# example
#  if ...;then
#    pass
#  elif ...; then
#    pass
#  else
#    reload_server
#  fi

  reload_server $server

  # 状态判断
  end_status_check_and_inlog

}

recovery_chain(){
  server='chain'
  reload_server $server

  # 状态判断
  end_status_check_and_inlog
}

recovery_api(){
  server='api'
  reload_server $server

  # 状态判断
  end_status_check_and_inlog

}

recovery_ipfs(){
  server='ipfs'
  reload_server $server

  # 状态判断
  end_status_check_and_inlog
}

recovery_smanager(){
  server='smanager'
  reload_server $server

  # 状态判断
  end_status_check_and_inlog
}

recovery_hight_rootfs_space(){

  step1(){
    # 清理crust 数据写入根分区的情况
    service zabbix-agent stop
    crust stop
    sleep 10
    for i in $(ls -d /disk*);do umount -f $i;done
    for d in $(du -sh /disk* | awk '{if ($1~/G/) print $2}');do cd "$d" || exit;rm -rf ./*;done
    mount -a
    cd /var/lib/docker/containers || exit 0;for i in $(find . -size +"$docker_log_size" | grep log$);do echo '' > $i;done
    crust start
    service zabbix-agent start
  }
  fs='/'
  clean_fs step1
  service zabbix-agent start

  if ! disk_space_isok;then
    reload_server
  fi

  if disk_space_isok;then
    log_in "$fs" 'success'
    exit 0
  else
    log_in "$fs" 'faild'
    exit 1
  fi
}

recovery_hight_cpu(){
  pass
}

recovery_hight_mem(){
  pass
}

case $1 in

  recovery_sworker)
    recovery_sworker
  ;;
  recovery_chain)
    recovery_chain
  ;;
  recovery_smanager)
    recovery_smanager
  ;;
  recovery_ipfs)
    recovery_ipfs
  ;;
  recovery_api)
    recovery_api
  ;;
  recovery_hight_rootfs_space)
    recovery_hight_rootfs_space

    # 清理 recovery 日志
    tail -n $log_save_rows ${work_dir}${recovery_log_name} > ${work_dir}${recovery_log_name}
  ;;
  recovery_hight_cpu)
    recovery_sworker
  ;;
  recovery_hight_mem)
    recovery_sworker
  ;;
esac