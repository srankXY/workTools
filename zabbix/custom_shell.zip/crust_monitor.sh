#!/bin/bash
logs_line=20
# docker 命令未用sudo 需把zabbix用户加入docker 组 usermod -aG docker zabbix && service zabbix-agent restart

# 获取容器名称用于日志查看
get_docker_name(){

  docker_name=$(docker ps -a | grep $server | awk '{print $NF}')
  # 如果是 chain 服务，则替换名称为 crust（服务器当中的容器名称为crust）
  if [[ $server == 'chain' ]];then docker_name='crust';fi
}

# 获取服务状态
get_server_status(){
  status=$(sudo /usr/bin/crust status  |grep $server |awk '{print $2}')
}

check_sworker(){
  server='sworker'
  get_docker_name
  get_server_status
  if [[ $status == 'running' && ! $(docker logs $docker_name --tail $logs_line 2> /dev/null | grep 'ERROR') ]];
    then
            echo 0
    else
            echo 1
  fi
}

check_chain(){
  server='chain'
  get_docker_name
  get_server_status
  if [[ $status == 'running' && ! $(docker logs $docker_name --tail $logs_line 2> /dev/null | grep 'ERROR') ]];
    then
            echo 0
    else
            echo 1
  fi
}


check_api(){
  server='api'
  get_docker_name
  get_server_status
  if [[ $status == 'running' && ! $(docker logs $docker_name --tail $logs_line 2> /dev/null | grep 'ERROR') ]];
    then
            echo 0
    else
            echo 1
  fi
}


check_smanager(){
  server='smanager'
  get_docker_name
  get_server_status
  if [[ $status == 'running' && ! $(docker logs $docker_name --tail $logs_line 2> /dev/null | grep 'ERROR') ]];
    then
            echo 0
    else
            echo 1
  fi
}


check_ipfs(){
  server='ipfs'
  get_docker_name
  get_server_status
  if [[ $status == 'running' && ! $(docker logs $docker_name --tail $logs_line 2> /dev/null | grep 'ERROR') ]];
    then
            echo 0
    else
            echo 1
  fi
}

crust_chain(){
  sudo docker logs crust-sworker-b --tail 200 |grep "crust chain failed" >/dev/null
  echo $?
}



# new add by xiaoyang.
# 获取根分区磁盘使用率
get_rootfs_space(){
  current_space=$(sudo df -Th | awk -F '[ %]' '{if ($NF=="/") print $(NF-2)}')
  echo $current_space
#  if [[ $current_space > 95 ]];then
#    echo 1
#    exit 0
#  fi
#  echo 0
}

# 获取cpu 空闲率
get_cpu_used(){
  cpu_used=$(sudo vmstat | awk '{print $(NF-2)}' | tail -n 1)
  echo $cpu_used
}

# 获取内存使用情况
get_mem_used(){
#  mem_used=$(free -m | awk 'NR==2{print $NF}')            # 获取可用内存（单位MB）
  mem_used=$(sudo free -m | awk 'NR==2{printf "%.2f", $3*100/$2 }')    # 获取内存使用率百分比
  echo $mem_used
}

case $1 in

  sworker)
    check_sworker
  ;;
  chain)
    check_chain
  ;;
  api)
    check_api
  ;;
  smanager)
    check_smanager
  ;;
  ipfs)
    check_ipfs
  ;;
  crust)
    crust_chain
  ;;
  get_rootfs_space)
    get_rootfs_space
  ;;
  get_cpu_used)
    get_cpu_used
  ;;
  get_mem_used)
    get_mem_used
  ;;
esac